// import logo from './logo.svg';
import './App.css';
import Button from './Button';
function App() {

  return (
    <>
    <center><h2>Click any button</h2></center>
    <div className='containerr'>
      <Button label="Button 1" />
      <Button label="Button 2" />
      <Button label="Button 3" />
    </div>
    </>
  )
};

export default App;
