import React from 'react';
import Board from './Board'; // Import your Board component
function App() { 
return (
<div className="App">
<h1>Tic Tac Toe Game</h1>
<Board /> {/* Render the Board component */}
</div>
);
}
export default App